#include "ordenacao.h"

#include <string.h>

void getNome(char nome[]) {
    // substitua por seu nome
    strncpy(nome, "Paulo Ricardo Lisboa de Almeida", MAX_CHAR);
    // adicionada terminação manual para caso de overflow
    nome[MAX_CHAR - 1] = '\0';
}

// adicionada terminação manual para caso de overflow
void getNomeAlgoritmoExtra(char nomeAlg[]) {
    // substitua pelo nome do algoritmo que você escolheu
    strncpy(nomeAlg, "MeuAlg", MAX_CHAR);
    nomeAlg[MAX_CHAR - 1] = '\0';
}

// a função a seguir deve retornar o seu número de GRR
uint32_t getGRR() { return 1234; }

uint64_t mergeSort(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t quickSort(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t heapSort(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t mergeSortSR(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t quickSortSR(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t heapSortSR(int vetor[], size_t tam) {
    vetor[0] = 99;
    return -1;
}

uint64_t algoritmoExtra(int vetor[], size_t tam){
    vetor[0] = 99;
    return -1;
}